# coding: utf-8
# @Author:Afun
# 得到resize的图片，以及将图片翻转得到双倍图片的数量
import os
from PIL import Image


def resize_and_rename_images(folder_path, new_size, new_name_prefix):
    # 遍历文件夹下的所有文件
    for filename in os.listdir(folder_path):
        # 确保文件是图片文件
        if filename.endswith(('.jpg', '.jpeg', '.png')):
            # 构建原始文件的完整路径
            old_image_path = os.path.join(folder_path, filename)

            # 打开图片并调整大小
            image = Image.open(old_image_path)
            resized_image = image.resize(new_size)

            # 构建新文件名
            new_filename = new_name_prefix + "_" + filename
            new_image_path = os.path.join(folder_path, new_filename)

            # 保存调整大小后的图片，并删除原始图片
            resized_image.save(new_image_path)
            os.remove(old_image_path)


def flip_images_in_folder(folder_path):
    # 遍历文件夹下的所有文件
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)

        # 检查文件是否是图片文件
        if not os.path.isfile(file_path) or not any(
                file_path.endswith(extension) for extension in ['.jpg', '.jpeg', '.png']):
            continue

        # 打开并水平翻转图片
        image = Image.open(file_path)
        flipped_image = image.transpose(Image.FLIP_LEFT_RIGHT)

        # 构造新的文件名（添加'_flipped'后缀）
        new_filename = os.path.splitext(filename)[0] + '_flipped' + os.path.splitext(filename)[1]
        new_file_path = os.path.join(folder_path, new_filename)

        # 保存翻转后的图片
        flipped_image.save(new_file_path)

        print(f"已翻转并保存图片：{new_filename}")


if __name__ == '__main__':
    path = 'keqin'
    new_size = (100, 100)  # 新的图片尺寸
    new_name_prefix = path  # 新的图片名字前缀

    resize_and_rename_images(path, new_size, new_name_prefix)

    # 调用函数进行水平翻转并保存
    flip_images_in_folder(path)
